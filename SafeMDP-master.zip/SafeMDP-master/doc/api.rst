API Documentation
*****************

.. automodule:: safemdp
