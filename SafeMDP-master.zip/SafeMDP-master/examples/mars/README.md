The experiments were run using Python 3 and the packages specified in the `requirements.txt` file.
